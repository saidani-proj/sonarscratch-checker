Administrators can install additional plugins from within the SonarQube UI (Administration > Marketplace).
They can also be downloaded for manual installation from:
- https://redirect.sonarsource.com/doc/plugin-library.html
